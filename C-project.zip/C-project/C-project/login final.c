#include<stdio.h>
#include<conio.h>
#include<string.h>
struct funders{
	char name[30];
	char transactionid[20];                    /// this structure is used in second module.
	char typeoffund[20];
    float amount;};


  struct bio
{
   char passcode[25];
   char usname[40];              //// used in login module.
}b;



       FILE*fb;
void enter(struct bio b)
{
   // system("clear");
   if((fb=fopen("authentication.bin","ab"))==NULL)
    printf("ERROR OPENING FILE");
   else
   {
     fwrite(&b,sizeof(struct bio),1,fb);
   printf("\n\nRECORDS SUCCESFULLY ADDED!!\n");
   printf("**********************************************\n\n");
   }
   fclose(fb);

}


  int check(struct bio a )
{
  // system("clear");
   if((fb=fopen("authentication.bin","rb"))==NULL)
    printf("ERROR OPENING FILE");
   else
   {
    while(fread(&b,sizeof(struct bio),1,fb))
     {
      if(!(strcmp(a.passcode,b.passcode))&&!(strcmp(a.usname,b.usname)))     //// this is used in login module.
       {                                                                         /// in this the the names from the user name and passward from fie are read and compared.
           fclose(fb);
           return 1;
       }



     }
   }
    return 0;
}





// this is function used in second module .
    int moneyread(char state[])
{
FILE *fp;
char state1[30];
float amount,amount1;
fp=fopen("b.txt","r");                           // file is open and this will read the content in file b.txt.
int res;
while(fscanf(fp,"%s %f",state1,&amount)!=EOF)    // it will read the content in the file until the fill is end.
{
res=strcmp(state1,state);          // in this the state is send as argument and the state is compared to the  correct state in file.
if(res==0)
{
amount1=amount;                // that state corresponding money will be inatalized to amount1 here.
}
}
fclose(fp);                     //file is closed here.
return amount1;                // and now the amount 1 will be returned.
}



/////// used in 3 module.

float calTotalAmount(){                          // this is a function with no argument and return type.

int nbags,vbags;
	float abag,totalAmount,vbag;
	printf("\nEnter no of ricebags\n");                              // in this function the user have to give no of bags of rice and vegitables and the price for that day.
	scanf("%d",&nbags);
	printf("Enter current Amount of each ricebag\n");
	scanf("%f",&abag);
	printf("Enter no of vegetables bags\n");
	scanf("%d",&vbags);
	printf("Enter current Amount of each vegetables bag\n");
	scanf("%f",&vbag);
	totalAmount=((nbags*abag)+(vbags*vbag))*0.0000001;             // here the total calculation is done and total amount for that thing will be  given to total amount.
	return totalAmount;                                            // here the  total amount will be returned.
	}







////1) first module
void statefund()
{
 FILE *fp;
 char state1[300];
float amount1;
fp=fopen("m.txt","r");         // the file is opened in read mode.
if(fp==NULL){
	printf("error");
}
else{

while(fscanf(fp,"%s%f",state1,&amount1)!=EOF)    /// here the file is read until the file is end .
{
	printf("\n%s       %f",state1,amount1);        //// here the content will be displayed on console.
}
}
 fclose(fp);                        /// the file is closed.
}





// second module

void funding()
{
	FILE *fund,*fp,*fp1;
	struct funders a;                                  ////the structure is name as 'a' in this line
char state[30],state1[30];
	int choice,c,n=2,res,f;
	float amount,amount1,ap,central,arunP,as,bir,ch,d,go,g,ha,hp,jh,k,ker,mp,maha,man,meg,miz,nl,ori,pb,rn,tn,tl,trip,up,u,wb,jk;
while(n==2)
	{
	fp=fopen("b.txt","r");                               // here the file "b.txt" is opened in read mode.
fp1=fopen("temp.txt","a");                               // here an extra "temp.txt" file is opened .
printf("c is choice\n");
	printf("enter your choice\n");
	printf("1.pm funds;2.cmfunds\n");
	scanf("%d",&c);                                       // here the user can choose wheater the funder want to give fund to central or state.
	if(c==1)
	{
	printf("Following modes of payments are available on the website pmindia.gov.in:\nDebit Cards and Credit Cards\nUPI (BHIM, PhonePe, Amazon Pay, Google Pay, PayTM, Mobikwik,\n");

		printf("u have chosen pm cares \nName of the Account: PM CARES\nAccount Number: 2121PM20202\nIFSC Code: SBIN0000691\nName of Bank & Branch: State Bank of India, New Delhi Main Branch\n");
		printf("enter the amount in crores\n");
   scanf("%f",&a.amount);                           // here the funder have to enter the amount given.
				strcpy(state1,"Central");            // here the string is copied to pass as an argument.
			ap=moneyread(state1);                     // the return value mentioned in above module is stored here.
				central=central+a.amount;            /// now the amount is added to the actual fund accounts information.
				amount1=central;                    // here the changed amount is stored to rewrite the file.
		}
else if(c==2)
		{
		printf("enter \n 1 for Andhra pradesh\n 2 for Arunachapl Pradesh\n 3 for Assam\n 4 for Bihar\n 5 for chattisghar\n 6 for Delhi\n 7 for Goa\n 8 for Gujarat\n 9 for Haryana \n 10 for Himachal Pradesh\n 11 for Jharkhand \n 12 for Karnataka\n 13 for Kerala \n 14 for Madhya Pradesh\n 15 for Maharashtra\n 16 for Manipur\n 17 for Meghalaya\n 18 for Mizoram \n 19 for Nagaland \n 20 for Odisha \n 21 for Punjab\n 22 for Rajasthan\n 23 for Tamil Nadu\n 24 for Telangana \n 25 for Tripura\n 26 for Uttar Pradesh\n 27 for Uttarakhand\n 28 for West Bengal\n 29 for Jammu and Kashmir ");
scanf("%d",&choice);
		    switch(choice)
		    {
		    case 1:
		    {		printf("Bank: Andhra Bank, Vijayawada\nAccount Number 1: 110310100029039\nIFS Code: ANDB0003079\nBranch: Velagapudi Secretariat Branch\n Bank: State Bank Of India, Vijayawada\nAccount Number 2: 38588079208\nIFS Code: SBIN0018884\nBranch: Velagapudi Secretariat Branch\n");
 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
		    		strcpy(state1,"Andhra");
			ap=moneyread(state1);
				ap=ap+a.amount;
				amount1=ap;
				break;		}
	case 2:
				   { printf("Bank: State Bank of India\naccount Number: 10940061389\nIFSC Code: SBIN0006091\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Arunachal");
		arunP=moneyread(state1);
		   arunP=arunP+a.amount;
		   amount1=arunP;
				   	break;		}
case 3:
				{	printf("Account Name:  Assam to Arogya Nidhi\naccount Number: 32124810101\nIFSC: SBIN0010755\n");
       printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Assam");
		 as=moneyread(state1);
		 	as=as+a.amount;
		   amount1=as;
					       break;  }
            case 4:
               { 	printf("Account Number: 2065104000002257\nIFSC: IBKL0002065\nBank: IDBI\n Kidwaipuri, Patna\n" );
              printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Bihar");
			bir=moneyread(state1);
  bir=bir+a.amount;
				amount1=bir;
               	 break;  }
             case 5:
                {    printf("A/c No.: 30198873179\nIFS Code: SBIN0004286\n");
          printf("enter the amount in crores\n");
scanf("%f",&a.amount);
		strcpy(state1,"Chattisgarh");
		ch=moneyread(state1);
				ch=ch+a.amount;
				amount1=ch;
                	   break;  }
             case 6:
               { 	printf("Account Number: 91042150000237\nBank: Syndicate Bank, Delhi, Secretariat Branch\nIFS Code: SYNB0009104\n");
           printf("enter the amount in crores\n");
scanf("%f",&a.amount);
strcpy(state1,"Delhi");
			d=moneyread(state1);
					d=d+a.amount;
				amount1=d;
               	     break;}
             case 7:
              {  	printf("Name of account: GOA STATE COVID-19 RELIEF ACCOUNT \nBank: SBI\n Number: 39235546238\ntails: Vidhan Bhawan, Panaji\nAccount\nIFS Code: SBIN0010719\nMICR Code: 403002058\nAddress of the bank: New Assembly Complex, Panaji, Goa, 401001\n");
			   printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	 	strcpy(state1,"Goa");
		go=moneyread(state1);
				 go=go+a.amount;
				amount1=go;
			             break;	}
case 8:
				{	printf("Account Name: CHIEF MINISTER'S RELIEF FUND\naccount Number: 10354901554\nBank & Branch: SBI, NSC BRANCH (08434)\niFSC: SBIN0008434\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Gujarat");
			g=moneyread(state1);
				g=g+a.amount;
				amount1=g;
						break;	}
case 9:
				{	printf("Account Number: 39234755902\nIFSC: SBIN0001509\nAddress: SBI, Sector - 10, Panchkula\n");
					 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
		strcpy(state1,"Harayana");
	ha=moneyread(state1);
				hp=hp+a.amount;
				amount1=ha;
			  break;  }
case 10:
			   { 	printf("Name of Account: HP COVID-19 Solidarity Response Fund\nAccount Number: 50100340267282\niFSC Code: HDFC0004116\nBank Name: HDFC Bank ltd\naddress: Chotta Shimla\n");
			printf("enter the amount in crores\n");
            scanf("%f",&a.amount);
		strcpy(state1,"Himachal");
			hp=moneyread(state1);
				hp=hp+a.amount;
				amount1=hp;
			   	 break;  }
 case 11:
				   { printf("bank: SBI\nBranch: Ranchi\nAccount Number: 11049021058\nIFSC Code: SBIN0000167\n");
 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
				strcpy(state1,"Jharkhand");
		jh=moneyread(state1);
					jh=jh+a.amount;
				amount1=jh;
					   	break;	}
case 12:
				   { printf("Bank Name: State Bank of India (SBI)\nbranch: Vidhana Soudha \nAccount Number: 39234923151\nIFS Code: SBIN0040277\nmICR No.: 560002419\n");
 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Karnataka");
				k=moneyread(state1);
			k=k+a.amount;
				amount1=k;
				   		   	break;		}
	case 13:
				   { printf("ACCOUNT NUMBER:39251566695\n IFSC:SBIN0070028\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"kerala");
ker=moneyread(state1);
				ker=ker+a.amount;
				amount1=ker;
						   break;	}
case 14:
				    {printf("Bank: State Bank of India\nbranch: Vallabh Bhawan\naccount Number: 10078152483\nIFSC: SBIN0001056\n");
 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Madhya");
		  mp=moneyread(state1);
				mp=mp+a.amount;
				amount1=mp;
				    	break;		}
	case 15:
				  {  printf("bank: State Bank of India\nBranch: Main Branch, Fort, Mumbai - 400023\nAccount Number: 39239591720\nIFS code: SBIN0000300\nbranch Code: 00300\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Maharastra");
		maha=moneyread(state1);
				maha=maha+a.amount;
				amount1=maha;
				  	break;	}
case 16:
  { //printf("Account Name: Chief Minister's COVID-19 Relief Fund\nBank Name: Manipur State Co-operative Bank Limited\nAccount Number: 70600875695\NIFS Code: YESB0MSCB01\nMICR Code: 795808002 \n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Manipur");
	man=moneyread(state1);
				man=man+a.amount;
				amount1=man;
				  	break;	}
		case 17:
				   { printf("Account Number 1: 38617186405\nIFSC: SBIN0006320\nBank: SBI\nBranch: Meghalaya Secretariat\nAccount Number 2: 500100307530750\nIFSC: HDFC0002934\nBank: HDFC Bank\nbranch: Laitumkhrah\n");
				   	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Meghalaya");
	meg=moneyread(state1);
			meg=meg+a.amount;
			amount1=meg;
						break;}
	case 18:
				   { printf("Bank: HDFC\nbranch: AizawlAccount Number: 18141450000025\nIFSC Code: HDFC0001814\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
strcpy(state1,"Mizoram");
		miz=moneyread(state1);
					miz=miz+a.amount;
				amount1=miz;
					   break;	}
case 19:
				  {  printf("Account Number: 10530527879\nIFSC Code: SBIN0000214\nbank: SBI\nBranch: Kohima\nPAN Card No. of Chief Minister?s Relief Fund:   AAAGC2036D\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Nagaland");
		nl=moneyread(state1);
				nl=nl+a.amount;
				amount1=nl;
						  break;	}
case 20:
				   { printf("Account Number: 39235504967\nIFSC: SBIN0010236\nbank Name: State Bank Of India\n");
			 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Orissa");
			ori=moneyread(state1);
				ori=ori+a.amount;
				amount1=ori;
					   break;	}
case 21:
				    {printf("Account Number: 50100333026124\nIFSC: HDFC0000213\nswiftcode\nHDFCINBB\nBranch code:0213 \n Branch name:Chandigarh,sector 17-C\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Punjab");
				pb=moneyread(state1);
					pb=pb+a.amount;
				amount1=pb;
							break;		}
case 22:
				   { printf("Account Number: 39233225397\nAddress: State Bank of India, Secretariat Branch, Jaipur\nBSR Code: 0028331\niFS Code: SBIN 0031031\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Rajastan");
			rn=moneyread(state1);
				rn=rn+a.amount;
				amount1=rn;
				   		break;		}
case 23:
				   { printf("Bank: Indian Overseas Bank\nbranch: Secretariat Branch, Chennai 600 009\nAccount Number: 11720 10000 00070\nIFS Code: IOBA0001172\ncMPRF PAN: AAAGC0038F\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Tamil");
			tn=moneyread(state1);
	tn=tn+a.amount;
				amount1=tn;
				   	break;	}
case 24:
				  {  printf("To Donate to CM Relief Fund, please send a Cheque on the name of CM Relief Fund, Telangana State, to the following address:cM Relief Fund,Revenue (CMRF) Department 3rd Floor, D BlockTelangana Secretariat Hyderabad,500022\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Telengana");
			tl=moneyread(state1);
	tl=tl+a.amount;
				amount1=tl;
				  	break;	}
	case 25:
				   { printf("Account Number: 37939987790\niFSC Code: SBIN0016355\nAddress: New Secretariat Branch (16355)\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Tripura");
		trip=moneyread(state1);
					trip=trip+a.amount;
				amount1=trip;
					   break;	}
	case 26:
				   { printf("Bank Name: Central Bank of India\nBranch Name: C.B.I. Cantt. Road, Lucknow\nAccount Number: 1378820696\niFSC: CBIN0281571\nBranch Code: 281571\n");
	 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Uttar");
			up=moneyread(state1);
				up=up+a.amount;
				amount1=up;
				   	break;		}
	case 27:
{printf("account number:303959543228\n IFS code:SBIN0010164\n");
 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
	strcpy(state1,"Uttarakhand");
u=moneyread(state1);
			u=u+a.amount;
				amount1=u;
 break;}
case 28:
				{	printf("\nbank: ICICI Bank Ltd.\nBranch: Howrah\nAccount Number: 628005501339\nIFS Code: ICIC0006280\nMICR Code: 700229010\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Westbengal");
	wb=moneyread(state1);
					wb=wb+a.amount;
				amount1=wb;
					 break;}
case 29:
				{	printf("Account Number: 0110010100000016\nBank Name: J& K Bank\nBranch: Moving Secretariat\niFS Code: JAKA0MOVING\nMICR Code: 190051062\nDemand Draft/Bank Draft: J& K Relief Fund\n");
		 printf("enter the amount in crores\n");
scanf("%f",&a.amount);
			strcpy(state1,"Jammu");
jk=moneyread(state1);
	jk=jk+a.amount;
				amount1=jk;
						break;	}
default:
printf("enter the correct number");
			}
}
while(fscanf(fp,"%s %f",state,&amount)!=EOF)       //here the file is opened and the information is read until the file ends.
{
res=strcmp(state,state1);                          // while the name of given state is same then the process will be done.
if(res==0)
{f=1;
//printf("enter the new amount\n");
//scanf("%f",&amount1);
fprintf(fp1,"%s %f\n",state,amount1);            // here the file is over written according to given info.
}
else
{
fprintf(fp1,"%s %f\n",state,amount);       /// or else the inforation is written as it is.
}
}

fclose(fp);
fclose(fp1);

 fp=fopen("b.txt","w");               // here the file "b.txt" is deleted.
 fclose(fp);

fp=fopen("b.txt","a");                  // here the file is again created with append mode.
 fp1=fopen("temp.txt","r");
 while(fscanf(fp1,"%s %f",state,&amount)!=EOF)
 {fprintf(fp,"%s %f\n ",state,amount);                    // here the content in the temp fie is coppied to actual file.
 }
fclose(fp);
fclose(fp1);
fp=fopen("temp.txt","w");    // here the content in temp file is deleted.
fclose(fp);

printf("enter the name\n");                   /// the information entered here is storeed in another file called "funder2.txt".
	scanf("%s",a.name);
  //  printf("enter the amount given\n");
//	scanf("%d",&a.amount);
	printf("enter transaction id\n");
	scanf("%s",a.transactionid);
	printf("enter the type of fund\n");
	scanf("%s",a.typeoffund);
	fund=fopen("funds2.txt","a");
	if(fund==NULL)
	{
	printf("the file does not exist");
		}
fprintf(fund,"name               amount given as fund           transaction id              type of fund\n");
fprintf(fund," %s                         %f                         %s               	          %s\n",a.name,a.amount,a.transactionid,a.typeoffund);
	fclose(fund);
printf("enter 2 for repeating again 0 for exit");           // here the user is given option weather to again give fund or not.
scanf("%d",&n);
}
}


   // 3 module



void comodities()
{ FILE *fp,*fp1;
	int c,res,f;
	char state1[30],state[30];
	float am,amount,amount1;
	fp=fopen("b.txt","r");
fp1=fopen("temp.txt","a");
     float  jk,pb,hp,ha,d,rn,up,u,mp,ch,g,maha,k,go,ker,tn,ap,tl,ori,bir,j,wb,as,
       arunP,man,meg,miz,nl,trip,central;

	printf("\nselect state to get money");
	printf("\nenter \n 1 for Andhra pradesh\n 2 for Arunachapl Pradesh\n 3 for Assam\n 4 for Bihar\n 5 for chattisghar\n 6 for Delhi\n 7 for Goa\n 8 for Gujarat\n 9 for Haryana \n 10 for Himachal Pradesh\n 11 for Jharkhand \n 12 for Karnataka\n 13 for Kerala \n 14 for Madhya Pradesh\n 15 for Maharashtra\n 16 for Manipur\n 17 for Meghalaya\n 18 for Mizoram \n 19 for Nagaland \n 20 for Odisha \n 21 for Punjab\n 22 for Rajasthan\n 23 for Tamil Nadu\n 24 for Telangana \n 25 for Tripura\n 26 for Uttar Pradesh\n 27 for Uttarakhand\n 28 for West Bengal\n 29 for Jammu and Kashmir ");
    scanf("\n%d",&c);
    switch(c)
	       {
		    case 1:
		    {
		     strcpy(state1,"Andhra");            // in this the string is copied to send to argument.
			ap=moneyread(state1);                   // here it is passed as an argument.
			printf("\nTotal amount in your state fund is %fcr",ap);
				am=calTotalAmount();                 //here the total amount on comoditiess will be calculated from function and stored here.
		    printf("the amount for comodities is %f\n",am);
			ap=ap-am;                                 // here the amount is reduced with actual amount.
			amount1=ap;                               // here the amount is assigned to update the file.
            printf("\nRemaining amount is %f",ap);
		    break;
			}
	        case 2:
	        {

		     strcpy(state1,"Arunachal");
			arunP=moneyread(state1);
            printf("\nTotal amount in your state fund is %fcr",arunP);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			arunP=arunP-am;
			amount1=arunP;
            printf("\nRemaining amount is %f",arunP);
		    break;
		    }

            case 3:
            {
            strcpy(state1,"Assam");
			as=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",as);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			as=as-am;
			amount1=as;
            printf("\nRemaining amount is %f",as);
		    break;
		    }

            case 4:
            {

			strcpy(state1,"Bihar");
			bir=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",bir);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			bir=bir-am;
			amount1=bir;
            printf("\nRemaining amount is %f",bir);
		    break;
		    }
            case 5:
            {

			strcpy(state1,"Chattisgarh");
			ch=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",ch);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			ch=ch-am;
			amount1=ch;
            printf("\nRemaining amount is %f",ch);
		    break;
		    }
            case 6:
            {

			strcpy(state1,"Delhi");
			d=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",d);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			d=d-am;
			amount1=d;
            printf("\nRemaining amount is %f",d);
            break;
		    }
            case 7:
            {

			strcpy(state1,"Goa");
			go=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",go);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			go=go-am;
			amount1=go;
            printf("\nRemaining amount is %f",go);
		    break;
		    }
            case 8:
			{

			strcpy(state1,"Gujarat");
			g=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",g);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			g=g-am;
			amount1=g;
            printf("\nRemaining amount is %f",g);
		    break;
		    }
            case 9:
		    {

			strcpy(state1,"Harayana");
			ha=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",ha);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			ha=ha-am;
			amount1=ha;
            printf("\nRemaining amount is %f",ha);
		    break;
		    }
            case 10:
			{

		     strcpy(state1,"Himachal");
			hp=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",hp);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			hp=hp-am;
			amount1=ap;
            printf("\nRemaining amount is %f",hp);
		    break;
		    }
            case 11:
		    {

			strcpy(state1,"Jammu");
			jk=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",jk);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			jk=jk-am;
			amount1=jk;
            printf("\nRemaining amount is %f",jk);
		    break;
		    }
            case 12:
		    {

		     strcpy(state1,"Karnataka");
			k=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",k);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			k=k-am;
			amount1=ap;
            printf("\nRemaining amount is %f",k);
		    break;
		    }
	        case 13:
		    {

		     strcpy(state1,"Kerala");
			ker=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",ker);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			ker=ker-am;
			amount1=ap;
            printf("\nRemaining amount is %f",ker);
		    break;
		    }
            case 14:
			{

		     strcpy(state1,"Madhya");
			mp=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",mp);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			mp=mp-am;
			amount1=mp;
            printf("\nRemaining amount is %f",mp);
		    break;
		    }
	        case 15:
			{

			strcpy(state1,"Maharastra");
			maha=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",mp);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			maha=maha-am;
			amount1=maha;
            printf("\nRemaining amount is %f",maha);
		    break;
		    }
            case 16:
			{

			strcpy(state1,"Manipur");
			man=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",man);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			man=man-am;
			amount1=man;
            printf("\nRemaining amount is %f",man);
		    break;
		    }
		    case 17:
		    {

			strcpy(state1,"Meghalaya");
			meg=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",meg);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			meg=meg-am;
			amount1=meg;
            printf("\nRemaining amount is %f",meg);
		    break;
		    }
	        case 18:
		    {

		    strcpy(state1,"Mizoram");
			miz=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",miz);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			miz=miz-am;
			amount1=miz;
            printf("\nRemaining amount is %f",miz);
		    break;
		    }
            case 19:
			{

			strcpy(state1,"Nagaland");
			nl=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",nl);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			nl=nl-am;
			amount1=nl;
            printf("\nRemaining amount is %f",nl);
		    break;
		    }
            case 20:
			{

			strcpy(state1,"Orissa");
			ori=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",ori);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			ori=ori-am;
			amount1=ap;
            printf("\nRemaining amount is %f",ori);
		    break;
		    }
            case 21:
			{

		    strcpy(state1,"Punjab");
			pb=moneyread(state1);
			printf("\nTotal amount in your state fund is %d=fcr",pb);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			pb=pb-am;
			amount1=pb;
            printf("\nRemaining amount is %f",pb);
		    break;
		    }
            case 22:
		    {

			strcpy(state1,"Rajastan");
			rn=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",rn);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			rn=rn-am;
			amount1=rn;
            printf("\nRemaining amount is %f",rn);
		    break;
		    }
            case 23:
		    {

			strcpy(state1,"Tamil");
			tn=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",tn);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			tn=tn-am;
			amount1=tn;
            printf("\nRemaining amount is %f",tn);
		    break;
		    }
            case 24:
			{

		     strcpy(state1,"Telangana");
			tl=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",tl);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			tl=tl-am;
			amount1=tl;
            printf("\nRemaining amount is %f",tl);
		    break;
		    }
	        case 25:
		    {

			strcpy(state1,"Tripura");
			trip=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",trip);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			trip=trip-am;
			amount1=trip;
            printf("\nRemaining amount is %f",trip);
		    break;
		    }
	        case 26:
			{

			strcpy(state1,"Uttar");
			up=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",up);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			up=up-am;
			amount1=up;
            printf("\nRemaining amount is %f",up);
		    break;
		    }
	        case 27:
            {

			strcpy(state1,"Uttarakhand");
			u=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",u);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			u=u-am;
			amount1=u;
            printf("\nRemaining amount is %f",u);
		    break;
		    }
            case 28:
			{

			strcpy(state1,"Westbengal");
			wb=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",wb);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			wb=wb-am;
			amount1=wb;
            printf("\nRemaining amount is %f",wb);
		    break;
		    }
            case 29:
			{

		     strcpy(state1,"Jharkhand");
			jk=moneyread(state1);
			printf("\nTotal amount in your state fund is %fcr",jk);
				am=calTotalAmount();
		    printf("the amount for comodities is %f\n",am);
			jk=jk-am;
			amount1=jk;
            printf("\nRemaining amount is %f  ",jk);
		    break;
		    }
default:
printf("enter the correct number");
			}
while(fscanf(fp,"%s %f",state,&amount)!=EOF)
{
res=strcmp(state,state1);
if(res==0)
{f=1;
//printf("enter the new amount\n");
//scanf("%f",&amount1);
fprintf(fp1,"%s %f\n",state,amount1);
}
else
{
fprintf(fp1,"%s %f\n",state,amount);
}
}
if(f==0)
{
printf("state is not found\n");
}
fclose(fp);
fclose(fp1);

 fp=fopen("b.txt","w");
 fclose(fp);

fp=fopen("b.txt","a");
 fp1=fopen("temp.txt","r");
 while(fscanf(fp1,"%s %f",state,&amount)!=EOF)
 {fprintf(fp,"%s %f\n ",state,amount);
 }
fclose(fp);
fclose(fp1);
fp=fopen("temp.txt","w");
fclose(fp);
}



 ///// this is fourth module.

void funders_view()
{ FILE *ftpr;
	ftpr=fopen("funds2.txt","r");          // this module is used to view the funders details.
	char c;
	int n;
	c=fgetc(ftpr);                         // this is simply reading a file.
	{if(ftpr==NULL)
	{
	printf("the file is empty");
	}
	else{
	while(c!=EOF)
	{
        printf("%c",c);
		c=getc(ftpr);
		}
		fclose(ftpr);
	}
}

}

///// this is module 5.

void latest_fundview()
{ FILE *file;
    file=fopen("b.txt","r");
	char ch;                                    // this is also simple reading of file.
{
ch=fgetc(file);
if(file==NULL)
	{
	printf("the file is empty");
	}
	else{
	while(ch!=EOF)
	{
        printf("%c",ch);
		ch=getc(file);
		}
		fclose(file);
	}
}
}




///// this the main program which is menu driven and done using modules.

void final()
{ int s,n=0;
while(n!=6)
{
	printf("\n");
    printf("\n");
    printf("\n");
printf("                            FUNDS FOR COVID-19\n");
	printf("\n");
printf("1) For Viewing the Funds given by Central to Respective States\n"
       "\n2) To Donate Funds for Central or State\n"
       "\n3) For Entering the Price of goods and getting the Total Money for distribution\n"
	   "\n4) For Viewing the Funders details\n"
       "\n5) For Viewing the Total Amount remained in the Respective State Funds\n"
	   "\n6) To Exit\n");
scanf("%d",&s);
switch(s)
{case 1:
	{  statefund();
	break;
	}
case 2:
{   funding();
break;
	}
case 3:
{   comodities();
break;
	}
	case 4:
	{funders_view();
	break;
		}
	case 5:
	{latest_fundview();
	break;
			}
	case 6:
{  exit(0);
	break;
}
	default:
	printf("wrong choice");
}
}
}

int main()
{
  int ch,nu=1;
  char a;
  int k;
  char passcode[25];
  char usname[40];
  int x;
  do
  {
   // system("clear");
  printf("                            AUTHENTICATION REQUIRED \n ");
  printf("                           ------------------------ \n ");
  printf("    Username:");
  scanf("%s",b.usname);
  printf("\n     Password:");
  scanf("%s",b.passcode);
  k=check(b);
  if(k==1)
  {
  printf("                            ACCESS GRANTED \n ");
  printf("                           --------------- \n ");

	final();

	 }
  else
  {
    printf("                            ACCESS DENIED \n ");
    printf("                            -------------\n ");
  printf(" the login is  still work  %d times \n \n  enter the user name and password properly\n\n",(5-nu));
   nu=nu+1;
   }

  } while (nu<=5);


  return 0;
}





